/************************************************************
 *							                                *
 *  Author:        Don Petersen                             *
 *  Course:        217A C++ Programming			            *
 *  Assignement:   Seminar 1, Ch. 2  Exercise 2		        *
 *  Description:   Ouitput C++                              *
 *  Input:         none				                        *
 *  Output:        multiple lines containing a message	    *
 *  Created:       05/08/2013				                *
 *  Last Modified: 05/10/2013				                *
 *							                                *
 ************************************************************/

#include <iostream>

using namespace std;


int main()
{
    cout << "\n\tCCCCCCCCC       ++                ++       "<< endl;
	cout <<	"\tCC              ++                ++       "<< endl;
	cout <<	"\tCC        ++++++++++++++    +++++++++++++++"<< endl;
	cout << "\tCC        ++++++++++++++    +++++++++++++++"<< endl;
	cout << "\tCC              ++                ++       "<< endl;
	cout << "\tCCCCCCCCC       ++                ++       "<< endl; 
    system("PAUSE");
	return 0;
}