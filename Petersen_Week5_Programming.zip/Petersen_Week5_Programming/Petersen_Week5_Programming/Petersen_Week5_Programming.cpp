/************************************************************
 *							                                *
 *  Author:        Don Petersen                             *
 *  Course:        217A C++ Programming			            *
 *  Assignement:   Seminar 5, Ch. 9  Exercise 4		        *
 *  Description:   Federal taxes                            *
 *  Input:         testScores.txt                           *                            
 *  Output:        distibuted scores                        *                              
 *  Created:       06/06/2013				                *
 *  Last Modified: 06/09/2013				                *
 *							                                *
 ************************************************************/

#include <iostream>
#include <fstream>
using namespace std;

int main() 
{

ifstream data("testScores.txt");
int arraysize;
double grades[100] = {0};
int ranges[8] = {0}; 



cout << "Enter Number of Scores to be distributed into score ranges: ";
cin >> arraysize;
cout << endl;


for(int i = 0; i < arraysize; i++)
        {
            data >> grades[i];
            data.ignore(2);
        }

for(int i = 0; i < arraysize; i++)
{
    if(grades[i] <= 24)
        ranges[0] = ranges[0] + 1;
    else if(grades[i] >= 25 && grades[i] <= 49)
        ranges[1] = ranges[1] + 1;
    else if(grades[i] >= 50 && grades[i] <= 74)
        ranges[2] = ranges[2] + 1;
    else if(grades[i] >= 75 && grades[i] <= 99)
        ranges[3] = ranges[3] + 1;
    else if(grades[i] >= 100 && grades[i] <= 124)
        ranges[4] = ranges[4] + 1;
    else if(grades[i] >= 125 && grades[i] <= 149)
       ranges[5] = ranges[5] + 1;
    else if(grades[i] >= 150 && grades[i] <= 174)
        ranges[6] = ranges[6] + 1;
    else if(grades[i] >= 175 && grades[i] <= 200)
        ranges[7] = ranges[7] + 1;
}


cout << "Number of Students: " << arraysize << endl;
cout << "0-24: " << ranges[0]<< endl;
cout << "25-49: " << ranges[1] << endl;
cout << "50-74: " << ranges[2] << endl;
cout << "75-99: " << ranges[3] << endl;
cout << "100-124: " << ranges[4] << endl;
cout << "125-149: " << ranges[5] << endl;
cout << "150-174: " << ranges[6] << endl;
cout << "175-200: " << ranges[7] << endl;

data.close();
system("PAUSE");
return 0;
}
