#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <fstream>

using namespace std;
// inputs data from .txt file to vectors.
void inputData(ifstream& inp, vector<int>& itemId, vector<string>& itemName, vector<int>& pOrdered, 
	             vector<double>& manufPrice, vector<double>& sellingPrice, vector<int>& pInStore);
void displayMenu(vector<int> itemId, vector<string> itemName, vector<int> pOrdered, vector<int>pInStore, vector<int> pSold, 
	             vector<double> manufPrice, vector<double> sellingPrice);
void itemCheck(vector<int> itemId, vector<string> itemName, vector<int> pOrdered, vector<int>pInStore, vector<int> pSold, 
	             vector<double> manufPrice, vector<double> sellingPrice);
void sellItem(vector<int> itemId, vector<string> itemName, vector<int> pOrdered, vector<int>pInStore, vector<int> pSold, 
	             vector<double> manufPrice, vector<double> sellingPrice);
void printReport(vector<int> itemId, vector<string> itemName, vector<int> pOrdered, vector<int>pInStore, vector<int> pSold, 
	             vector<double> manufPrice, vector<double> sellingPrice);

int main()
{
 vector<int> itemId(10);
 vector<string> itemName(10);
 vector<int> pOrdered(10);
 vector<int> pInStore(10);
 vector<int> pSold(10);
 vector<double> manufPrice(10);
 vector<double> sellingPrice(10);
 ifstream inData;
 int x=0;
 
 inData.open("Final.txt");
 if (!inData)
 {
	 cout << "Input file (Final.txt) does not exist." << endl;
	 return 0;
 }
 
 inputData(inData, itemId, itemName, pOrdered, manufPrice, sellingPrice, pInStore);
 
 while (x != -1)
 {
	displayMenu(itemId, itemName, pOrdered, pInStore, pSold, manufPrice, sellingPrice);
 }
 inData.close();

 system("PAUSE");
 return 0;
}

void displayMenu(vector<int> itemId, vector<string> itemName, vector<int> pOrdered, vector<int>pInStore, vector<int> pSold, 
	             vector<double> manufPrice, vector<double> sellingPrice) 

{
	string menuChoice;
	cout << "                     Friendly Hardware Store" << endl << endl;
	cout << "Menu Choices:" << endl;
	cout << "Type \"Check\" to check the store inventory for an item," << endl;
	cout << "Type \"Sell\" to report that an item has been sold," << endl;
	cout << "Type \"Report\" to have the weekly report print onto the screen: ";
	cin >> menuChoice;

	if (menuChoice == "Check" || menuChoice == "check") 
	{
	//call function to check inventory
	itemCheck(itemId, itemName, pOrdered, pInStore, pSold, manufPrice, sellingPrice);
	}
	else if (menuChoice == "Sell" || menuChoice == "sell")
	{
	//call function to sell(remove) item from inventory
	sellItem(itemId, itemName, pOrdered, pInStore, pSold, manufPrice, sellingPrice);
	}
	else if (menuChoice == "Report" || menuChoice == "report")
	{
	//call function to print report
	printReport(itemId, itemName, pOrdered, pInStore, pSold, manufPrice, sellingPrice);
	}
}

void itemCheck(vector<int> itemId, vector<string> itemName, vector<int> pOrdered, vector<int>pInStore, vector<int> pSold, 
	             vector<double> manufPrice, vector<double> sellingPrice)
{
	
	int item;
		
	cout << "\nEnter item's ID you would like to check for: " << endl;
	cin >> item;

		for(unsigned int x = 0; x < itemId.size(); x++)
		{
			if (itemId[x] == item)
			{
			cout << "There are " << pInStore[x] << " of this particular item." 
			<< endl;
			}
			else if (itemId[x] != item)
			{
			cout << "Item does not exist." << endl;
			}
  }
		//Shows the number of items in the Inventory but then follows with 9 lines 
		// of "Item doesn not exist". 
		
}

void sellItem(vector<int> itemId, vector<string> itemName, vector<int> pOrdered, vector<int>pInStore, vector<int> pSold, 
	             vector<double> manufPrice, vector<double> sellingPrice)
{
	int itemNumber, NumSold;
	
	cout << "\nEnter Item Number of item to be sold: ";
	cin >> itemNumber;

	for (int x=0; x < itemId.size(); x++)
		if (itemId[x] == itemNumber)
	{
		cout << "\nEnter Number of the item that were sold: ";
		cin >> NumSold;
		cout << endl;
		pInStore[x] -= NumSold;
		pSold[x] += NumSold;
		cout << pInStore[x] << " " << pSold[x]; //FOO
	}
	//pInStore and pSold are showing that they changed but then if we run a printReport
	// it isn't showing the updated pInStore or pSold.
}

void printReport(vector<int> itemId, vector<string> itemName, vector<int> pOrdered, vector<int>pInStore, vector<int> pSold, 
	             vector<double> manufPrice, vector<double> sellingPrice) 
{
	unsigned int i;
    int totalItems = 0;
    double totalInventory = 0;
    
	cout << "\n                    Friendly Hardware Store" << endl << endl;
    cout << "itemID ItemName     pOrdered pInStore pSold manufPrice sellingPrice" << endl;
    cout << fixed << showpoint;
    cout << setprecision(2);   

    
    for (i = 0; i < itemId.size(); i++)
    {
        cout << left;
        cout << setw(6) << itemId.at(i);
        cout << setw(15) << itemName.at(i);
        cout << right;
        cout << setw(7) << pOrdered.at(i);
        cout << setw(9) << pInStore.at(i);
        cout << setw(6) << pSold.at(i);
        cout << setw(11) << manufPrice.at(i);
        cout << setw(13) << sellingPrice.at(i) << endl;
 
        
		totalInventory += pInStore.at(i) * sellingPrice.at(i);
        totalItems += pInStore.at(i);
    }
    cout << endl;
    cout << "Total Inventory: $" << totalInventory << endl;
    cout << "Total number of items in the store: " << totalItems << endl;
}

void inputData(ifstream& inp, vector<int>& itemId, vector<string>& itemName, vector<int>& pOrdered, 
	             vector<double>& manufPrice, vector<double>& sellingPrice, vector<int>& pInStore)
{
	// variables to hold input from .txt file.
	int itemIdString;
	string itemNameString;
	int pOrderedInt;
	double manufPriceDouble;
	double sellingPriceDouble;
	int index = 0;

	inp >> itemIdString >> itemNameString >> pOrderedInt >> manufPriceDouble >> sellingPriceDouble;
	// while loop that inputs data into the vectors
	while (inp)
	{
		itemId[index] = itemIdString;
		itemName[index] = itemNameString;
		pOrdered[index] = pOrderedInt;
		manufPrice[index] = manufPriceDouble;
		sellingPrice[index] = sellingPriceDouble;
		pInStore[index] += pOrderedInt;

		inp >> itemIdString >> itemNameString >> pOrderedInt >> manufPriceDouble >> sellingPriceDouble;
		
		index++;
		  
	}
	
}