/************************************************************
 *							                                *
 *  Author:        Don Petersen                             *
 *  Course:        217A C++ Programming			            *
 *  Assignement:   Seminar 4, Ch. 8  Exercise 5		        *
 *  Description:   Federal taxes                            *
 *  Input:         User Information                         *                            
 *  Output:        Taxes owed                               *                              
 *  Created:       06/02/2013				                *
 *  Last Modified: 06/04/2013				                *
 *							                                *
 ************************************************************/


#include <iostream>
#include <cmath>
#include <string>

using namespace std;

void getData();
double taxAmount(int, double, double, int);

int main()
{
	int restart = 0;
	while (restart >= 0)
	{
		getData();
		
	}
	return 0;
	
}

void getData()
{
	string maritalStatus;
	int standardExemption, noOfChildren, people;
	double tax, salary, pensionPercent, pension;
	
    
		
	cout << "\nEnter Marital Status: ";
	cin >> maritalStatus;
	if (maritalStatus == "Married" || maritalStatus == "married")
	{	
		cout << "\nEnter number of dependant children under the age of 14: ";
		cin >> noOfChildren;
		cout << endl;
		
		people = 2 + noOfChildren;
		standardExemption = 7000;
			
	}
	else if (maritalStatus == "Single" || maritalStatus == "single")
	{
		cout << endl;
		standardExemption = 4000;
		people = 1;
		
	 }
	else 
	{ 
		cout << "\nIllegal marital status.\n" << endl;
		main();                   //This seems to work but for some reason it sets off my spidey senses
		                          //Is this bad programming practices or ok to do?
		                          //The intention is to get back to the begining of the program. 
	}
	cout << "Enter Gross Salary (If married enter combined income): ";
	cin >> salary;
	cout << endl;
	
	cout << "Enter the percent of gross incline contributed to a pension fund: ";
	cin >> pensionPercent;
	if (pensionPercent > 6)
	{
		cout << "\nPercent contributed to pension fund cannot exceed 6%.\n" 
		<< "Enter new percent contributed: ";
	    cin >> pensionPercent;
	}
	pension = salary * (pensionPercent / 100);
	
	tax = taxAmount(people, salary, pension, standardExemption);	          	

	cout << "\nAmmount of Federal Taxes owed is: "<< tax << endl;
}

double taxAmount(int people, double salary, double pension, int standardExemption)
{
    double taxableIncome, taxOwed=0;
	
	taxableIncome = salary - (standardExemption + pension + (people * 1500));

	if (taxableIncome >= 0 && taxableIncome <= 15000)
	{
		taxOwed = taxableIncome * .15;
	}
	else if (taxableIncome > 15000 && taxableIncome <= 40000)
	{
		taxOwed = 2250 + ((taxableIncome - 15000) * .25);
	}
	else if (taxableIncome > 40000)
	{
		taxOwed = 8460 + ((taxableIncome - 40000) * .35); 
	}
	return taxOwed;

}