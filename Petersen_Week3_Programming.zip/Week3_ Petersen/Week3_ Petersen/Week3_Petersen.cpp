/************************************************************
 *							                                *
 *  Author:        Don Petersen                             *
 *  Course:        217A C++ Programming			            *
 *  Assignement:   Seminar 3, Ch. 6  Exercise 1		        *
 *  Description:   Ouitput C++                              *
 *  Input:         10, 34, 22, 333, 678, 67876, 44444,      *
 *                 123454321                                *
 *  Output:        Tells user whether the number is         *
 *                 a Palindrome                             *
 *  Created:       05/23/2013				                *
 *  Last Modified: 05/28/2013				                *
 *							                                *
 ************************************************************/

#include <iostream>
#include <cmath>
using namespace std;

bool isNumPalindrome(int num)
{
	int pwr = 0;

	if (num < 10)
		return true;
	else
	{
		while (num / static_cast<int>(pow(10.0, pwr)) >= 10)
			pwr++;
		while (num >= 10)
		{
			int tenTopwr = static_cast<int>(pow(10.0, pwr));

			if ((num / tenTopwr) != (num % 10))
				return false;
			else 
			{
				num = num % tenTopwr;
				num = num / 10;
				pwr = pwr - 2;
			}
		} //end while
		return true;
	}//end else
}

int main()
{
	int number;
	bool palindrome = false;
		
	do
	{
	    cout << "Enter Number to see if it is a Palindrome: " << endl;
		cin >> number;
		palindrome = isNumPalindrome(number);
	if (palindrome == true)
		cout << "This number is a Palindrome." << endl << endl;
	else
		cout << "This number is not a Palindrome." << endl << endl;
	
	} 
	while (number != -999);
		
	system("PAUSE");
	return 0;
}