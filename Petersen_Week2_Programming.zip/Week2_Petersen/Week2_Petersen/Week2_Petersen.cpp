/************************************************************
 *							                                *
 *  Author:        Don Petersen                             *
 *  Course:        217A C++ Programming			            *
 *  Assignement:   Seminar 2, Ch. 4  Exercise 6		        *
 *  Description:   Ouitput C++                              *
 *  Input:         lengths of 3 triangle sides              *
 *  Output:        Tells user whether legnths make a right  *
 *                 triangle                                 *
 *  Created:       05/15/2013				                *
 *  Last Modified: 05/15/2013				                *
 *							                                *
 ************************************************************/

#include <iostream>
#include <cmath>

using namespace std;

int main()
{
	double a, b, c;
				
	cout << "Enter the length of side a: " << endl;
	cin >> a;
	cout << "Enter the length of side b: " << endl;
	cin >> b;
	cout << "Enter the length of side c: " << endl;
	cin >> c;
	
	a = pow(a,2);
	b = pow(b,2);
	c = pow(c,2);
	
	if (a == b + c) {
        cout << "Congratulations! Lengths a, b, and c make a Right Triangle" << endl;
	}  else if (b == a + c) {
		cout << "Congratulations! Lengths a, b, and c make a Right Triangle" << endl;
	}  else if (c == a + b) {
		cout << "Congratulations! Lengths a, b, and c make a Right Triangle" << endl;
	}  else {
		cout << "Sorry, lengths a, b, and c do not make a Right Triangle" << endl;  
	}
	system("PAUSE");
    return 0;
}
